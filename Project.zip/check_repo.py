"""Pre-submission self-check against the assignment's rules. Run: python check_repo.py"""
import sys
from pathlib import Path

import joblib
import pandas as pd

from metrics_utils import evaluate_model

ok = True


def check(label, passed, hint=""):
    global ok
    ok &= bool(passed)
    print(f"[{'PASS' if passed else 'FAIL'}] {label}" + ("" if passed else f"  -> {hint}"))


# 1. required files (Step 3)
for f in ["app.py", "requirements.txt", "README.md", "test_data.csv", "model/meta.joblib"]:
    check(f"file exists: {f}", Path(f).exists(), "missing")

meta = joblib.load("model/meta.joblib")
for name, fname in meta["models"].items():
    check(f"saved model: model/{fname}", (Path("model") / fname).exists(), "run train_models.py")
check("exactly five models", len(meta["models"]) == 5, f"found {len(meta['models'])}")

# 2. dataset rules (Step 1)
check("features >= 12", len(meta["feature_names"]) >= 12)
test = pd.read_csv("test_data.csv")
check("test_data.csv has all features + target",
      set(meta["feature_names"] + [meta["target"]]) <= set(test.columns))
check("test_data.csv has rows", len(test) > 0)

# 3. models load and score without refitting (Step 6 rule)
X = test[meta["feature_names"]]
y = test[meta["target"]].map({c: i for i, c in enumerate(meta["class_names"])})
for name, fname in meta["models"].items():
    try:
        m, _ = evaluate_model(joblib.load(Path("model") / fname), X, y, len(meta["class_names"]))
        check(f"{name}: all 6 metrics computed", not any(pd.isna(v) for v in m.values()))
    except Exception as e:
        check(f"{name}: loads and predicts", False, repr(e))

# 4. requirements.txt (Step 4)
req = Path("requirements.txt").read_text().lower() if Path("requirements.txt").exists() else ""
for lib in ["streamlit", "scikit-learn", "numpy", "pandas", "matplotlib", "seaborn", "joblib"]:
    check(f"requirements.txt lists {lib}", lib in req)

# 5. app features (Step 6): static look for the four mandatory features
app = Path("app.py").read_text()
check("app: CSV upload", "file_uploader" in app)
check("app: model dropdown", "selectbox" in app)
check("app: metrics displayed", ".metric(" in app)
check("app: confusion matrix + classification report", "plot_confusion" in app and "report_dict" in app)
check("app does not retrain", ".fit(" not in app)

# 6. README structure and unfinished placeholders (Step 5)
readme = Path("README.md").read_text()
for sec in ["Problem statement", "Dataset description", "GitHub repository", "Models used",
            "Observations", "Overall winner"]:
    check(f"README section: {sec}", sec.lower() in readme.lower())
check("README has no TODO left", "TODO" not in readme, f"{readme.count('TODO')} TODO(s) remaining")
check("README has no empty metric cells", "| | | | | | |" not in readme, "fill the metrics table")

print("\nALL CHECKS PASSED" if ok else "\nSOME CHECKS FAILED - fix the FAIL lines above")
sys.exit(0 if ok else 1)
